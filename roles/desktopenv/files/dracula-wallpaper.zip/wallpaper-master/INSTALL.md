### Dracula wallpapers

#### Download

Wallpapers can be downloaded as [`.zip`](https://github.com/dracula/wallpaper/archive/master.zip), or you can clone the [GitHub repository](https://github.com/dracula/wallpaper) directly with the command below:

```bash

git clone https://github.com/dracula/wallpaper.git

```

There are two collections, separated into folders with their respective names.
